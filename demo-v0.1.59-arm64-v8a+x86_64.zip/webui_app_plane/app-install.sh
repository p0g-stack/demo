#!/system/bin/sh
# flutter_p0g: installs this module's app plane app (generated at build).
# Usage: sh app-install.sh [--if-missing]
PKG=com.webui.api.demo
VC=1011
APK=${0%/*}/app.apk

case "$(pm path $PKG 2>/dev/null </dev/null)" in
  package:*)
    [ "$1" = --if-missing ] && exit 0
    v=$(dumpsys package $PKG 2>/dev/null | grep -m1 versionCode=)
    v=${v#*versionCode=}; v=${v%% *}
    if [ "$v" = "$VC" ]; then echo "$PKG $VC is installed"; exit 0; fi ;;
esac

after_install() {
  # The two settings Termux:API's own main screen (TermuxAPIMainActivity)
  # asks the user for, best effort: draw over other apps, so an activity
  # started from a broadcast (Share's chooser, dialogs) is not blocked as a
  # background activity start (devicelab, Android 15); battery optimization
  # off, "so that termux-api script can start it from the background".
  appops set "$PKG" SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1
  dumpsys deviceidle whitelist +"$PKG" >/dev/null 2>&1
}

# ---- GAP: install-time settings around the session, filled by the maintainer ----
before_install() {
  VERIFIER_ADB=$(settings get global verifier_verify_adb_installs) || return 1
  VERIFIER_PACKAGE=$(settings get global package_verifier_enable) || return 1
  VERIFIER_PAUSED=1
  trap 'restore_after_install' 0
  trap 'exit 1' 1 2 15
  settings put global verifier_verify_adb_installs 0 &&
    settings put global package_verifier_enable 0
}

restore_setting() {
  case "$2" in
    null) settings delete global "$1" >/dev/null ;;
    *) settings put global "$1" "$2" ;;
  esac
}

restore_after_install() {
  [ "$VERIFIER_PAUSED" = 1 ] || return 0
  result=0
  restore_setting verifier_verify_adb_installs "$VERIFIER_ADB" || result=1
  restore_setting package_verifier_enable "$VERIFIER_PACKAGE" || result=1
  [ "$result" = 0 ] && VERIFIER_PAUSED=0
  return "$result"
}

# ---- end of GAP ----

T=/data/local/tmp/webui-app-plane-$PKG.apk
cp -f "$APK" "$T" && chmod 644 "$T" && chown 1000:1000 "$T"
chcon u:object_r:apk_data_file:s0 "$T" 2>/dev/null
SZ=$(stat -c %s "$T")
before_install || { echo "! Could not pause package verifier"; exit 1; }
O=$(pm install-create --user 0 -i com.android.vending -r -S "$SZ" 2>&1 </dev/null)
case "$O" in
  *'['*']'*)
    S=${O#*[}; S=${S%%]*}
    O=$(pm install-write -S "$SZ" "$S" base.apk "$T" 2>&1 </dev/null)
    case "$O" in
      *Success*) O=$(pm install-commit "$S" 2>&1 </dev/null) ;;
      *) pm install-abandon "$S" >/dev/null 2>&1 </dev/null ;;
    esac ;;
esac
restore_after_install || { echo "! Could not restore package verifier"; exit 1; }
trap - 0 1 2 15
after_install
rm -f "$T"

case "$O" in
  *Success*) echo "Installed $PKG $VC" ;;
  *)
    echo "! Installing $PKG failed: $O"
    case "$O" in
      *UPDATE_INCOMPATIBLE*) echo "! It is signed with another key: uninstall $PKG, then install the module again" ;;
    esac
    exit 1 ;;
esac
