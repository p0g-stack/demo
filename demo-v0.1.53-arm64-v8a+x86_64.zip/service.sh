#!/system/bin/sh
# flutter_p0g: reinstall the app plane app if it was removed (generated at build).
(MODDIR=${0%/*}; until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 2; done; sh "$MODDIR/webui_app_plane/app-install.sh" --if-missing >"$MODDIR/webui_app_plane/app-install.log" 2>&1) &
