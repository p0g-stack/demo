#!/system/bin/sh
# flutter_p0g: free the data folder (generated at build).
MODPATH=${0%/*}; rm -rf "/data/adb/${MODPATH##*/}"
# flutter_p0g: remove the app plane app (generated at build).
nohup sh -c 'until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 2; done; pm uninstall com.webui.api.demo' >/dev/null 2>&1 &
