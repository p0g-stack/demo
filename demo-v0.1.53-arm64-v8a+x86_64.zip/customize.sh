# Runs once at install under KernelSU, APatch or Magisk; $MODPATH is the module.
# The app's root process (cli/, if any) ships in bin/.
if [ -d "$MODPATH/bin" ]; then
  set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
fi
# flutter_p0g: the programs it ships (generated at build).
set_perm_recursive "$MODPATH/flutter_webui" 0 0 0755 0755
set_perm_recursive "$MODPATH/webui_app_plane" 0 0 0755 0755
# flutter_p0g: one Dart runtime per ABI, linked where the app runs it (generated at build).
mkdir -p "$MODPATH/bin/arm64-v8a" && { ln -f "$MODPATH/flutter_webui/arm64-v8a/dartaotruntime" "$MODPATH/bin/arm64-v8a/dartaotruntime" 2>/dev/null || { cp -f "$MODPATH/flutter_webui/arm64-v8a/dartaotruntime" "$MODPATH/bin/arm64-v8a/dartaotruntime" && set_perm "$MODPATH/bin/arm64-v8a/dartaotruntime" 0 0 0755; }; }
mkdir -p "$MODPATH/bin/x86_64" && { ln -f "$MODPATH/flutter_webui/x86_64/dartaotruntime" "$MODPATH/bin/x86_64/dartaotruntime" 2>/dev/null || { cp -f "$MODPATH/flutter_webui/x86_64/dartaotruntime" "$MODPATH/bin/x86_64/dartaotruntime" && set_perm "$MODPATH/bin/x86_64/dartaotruntime" 0 0 0755; }; }
# flutter_p0g: the data folder /data/adb/demo (generated at build).
[ -d /data/adb/modules/demo ] || rm -rf /data/adb/demo
KSU_MODULE=demo /data/adb/ksud module config set webui.installed 1 || ui_print "! ksud module config failed: KernelSU 3.0+ or KernelSU Next 3.0+ is needed"
# flutter_p0g: install or update the app plane app (generated at build).
sh "$MODPATH/webui_app_plane/app-install.sh" 2>&1 | while IFS= read -r l; do ui_print "  $l"; done
